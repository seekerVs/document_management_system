import 'dart:io';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class PdfViewer extends StatefulWidget {
  final String localPath;
  final void Function(int totalPages) onRender;
  final void Function(int currentPage, int totalPages) onPageChanged;
  final void Function(String error) onError;
  final void Function(PdfViewerController controller)? onControllerReady;

  const PdfViewer({
    super.key,
    required this.localPath,
    required this.onRender,
    required this.onPageChanged,
    required this.onError,
    this.onControllerReady,
  });

  @override
  State<PdfViewer> createState() => _PdfViewerState();
}

class _PdfViewerState extends State<PdfViewer> {
  final PdfViewerController _controller = PdfViewerController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.onControllerReady?.call(_controller);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox.expand(
      child: SfPdfViewer.file(
        File(widget.localPath),
        controller: _controller,
        scrollDirection: PdfScrollDirection.vertical,
        onDocumentLoaded: (details) {
          widget.onRender(details.document.pages.count);
        },
        onPageChanged: (details) {
          widget.onPageChanged(details.newPageNumber, details.newPageNumber);
        },
        onDocumentLoadFailed: (details) {
          widget.onError(details.description);
        },
      ),
    );
  }
}

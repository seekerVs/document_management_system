import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:uuid/uuid.dart';
import '../../../../../Utils/Constant/colors.dart';
import '../../../../../Utils/Constant/enum.dart';
import '../../../../../Utils/Routes/main_routes.dart';
import '../Model/signature_field_model.dart';
import '../Model/signature_request_model.dart';
import 'signature_request_controller.dart';

// Signer color palette — one color per signer index
const List<Color> _signerColors = [
  AppColors.primary,
  AppColors.signatureCompleted,
  AppColors.signaturePending,
  AppColors.error,
];

class SignaturePlacementController extends GetxController {
  final SignatureRequestController _requestController =
      Get.find<SignatureRequestController>();

  final RxInt activeSignerIndex = 0.obs;
  // Live drag positions tracked separately from model for performance
  final RxMap<String, ({double x, double y})> fieldPositions =
      <String, ({double x, double y})>{}.obs;

  List<SignerModel> get activeSigners => _requestController.signers
      .where((s) => s.role == SignerRole.needsToSign)
      .toList();

  SignerModel? get activeSigner {
    final signers = activeSigners;
    if (signers.isEmpty) return null;
    // Clamp index in case it's stale from a previous session
    final index = activeSignerIndex.value.clamp(0, signers.length - 1);
    return signers[index];
  }

  // All fields across all signers flattened for rendering
  List<({SignerModel signer, SignatureFieldModel field, int signerIndex})>
  get allFields {
    final result =
        <({SignerModel signer, SignatureFieldModel field, int signerIndex})>[];
    for (var i = 0; i < activeSigners.length; i++) {
      for (final field in activeSigners[i].fields) {
        result.add((signer: activeSigners[i], field: field, signerIndex: i));
      }
    }
    return result;
  }

  // Return color for a given signer index
  Color signerColor(int index) => _signerColors[index % _signerColors.length];

  // Switch active signer context
  void switchSigner(int index) => activeSignerIndex.value = index;

  // Add field at center of canvas for active signer
  void addField(
    SignatureFieldType type,
    double canvasWidth,
    double canvasHeight,
  ) {
    final signer = activeSigner;
    if (signer == null) return;
    const fieldW = 160.0;
    const fieldH = 60.0;
    final field = SignatureFieldModel(
      fieldId: const Uuid().v4(),
      type: type,
      page: 0,
      x: (canvasWidth / 2) - (fieldW / 2),
      y: (canvasHeight / 2) - (fieldH / 2),
      width: fieldW,
      height: fieldH,
    );
    fieldPositions[field.fieldId] = (x: field.x, y: field.y);
    _updateSignerFields(signer, [...signer.fields, field]);
  }

  // Update live position on drag
  void updateFieldPosition(
    String fieldId,
    double dx,
    double dy,
    double canvasWidth,
    double canvasHeight,
  ) {
    final current = fieldPositions[fieldId];
    if (current == null) return;
    const fieldW = 160.0;
    const fieldH = 60.0;
    final newX = (current.x + dx).clamp(0.0, canvasWidth - fieldW);
    final newY = (current.y + dy).clamp(0.0, canvasHeight - fieldH);
    fieldPositions[fieldId] = (x: newX, y: newY);
  }

  // Commit position to model after drag ends
  void commitFieldPosition(String fieldId, SignerModel signer) {
    final pos = fieldPositions[fieldId];
    if (pos == null) return;
    final updated = signer.fields.map((f) {
      if (f.fieldId != fieldId) return f;
      return f.copyWith(x: pos.x, y: pos.y);
    }).toList();
    _updateSignerFields(signer, updated);
  }

  // Delete a placed field
  void deleteField(String fieldId, SignerModel signer) {
    fieldPositions.remove(fieldId);
    final updated = signer.fields.where((f) => f.fieldId != fieldId).toList();
    _updateSignerFields(signer, updated);
  }

  // Proceed to review step
  void goToReview() => Get.toNamed(MainRoutes.requestReview);

  // Write updated fields back to parent controller
  void _updateSignerFields(
    SignerModel signer,
    List<SignatureFieldModel> fields,
  ) {
    final index = _requestController.signers.indexWhere(
      (s) => s.signerEmail == signer.signerEmail,
    );
    if (index == -1) return;
    _requestController.signers[index] = signer.copyWith(fields: fields);
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import '../../../../../Commons/Styles/style.dart';
import '../../../../../Commons/Widgets/app_avatar.dart';
import '../../../../../Commons/Widgets/app_button.dart';
import '../../../../../Utils/Constant/colors.dart';
import '../../../../../Utils/Constant/enum.dart';
import '../../../../../Utils/Formatters/formatter.dart';
import '../../../../../Utils/Constant/images.dart';
import '../Controller/signature_request_controller.dart';
import '../Model/signature_request_model.dart';

class RequestReviewView extends GetView<SignatureRequestController> {
  const RequestReviewView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Review & Send'),
        leading: IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: Get.back,
        ),
      ),
      body: Obx(() {
        final doc = controller.selectedDocument.value;
        final signers = controller.signers;
        return Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // Document section
                  const _SectionLabel(label: 'Document'),
                  const SizedBox(height: 8),
                  if (doc != null)
                    Container(
                      decoration: AppStyle.card(),
                      child: ListTile(
                        contentPadding: const EdgeInsets.only(left: 16),
                        leading: SvgPicture.asset(
                          AppImages.iconPdf,
                          width: 40,
                          height: 40,
                        ),
                        title: Text(
                          doc.name,
                          style: Theme.of(context).textTheme.titleSmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(
                          doc.sizeLabel,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ),
                    ),
                  const SizedBox(height: 24),
                  // Recipients section
                  const _SectionLabel(label: 'Recipients'),
                  const SizedBox(height: 8),
                  ...signers.map(
                    (s) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _ReviewSignerTile(signer: s),
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Signing order indicator
                  if (controller.signingOrderEnabled.value)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      decoration: AppStyle.card(),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.sort_outlined,
                            color: AppColors.primary,
                            size: 18,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Signing order is enabled',
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(color: AppColors.primary),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            _BottomActions(controller: controller),
          ],
        );
      }),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(label, style: Theme.of(context).textTheme.titleMedium);
  }
}

class _ReviewSignerTile extends StatelessWidget {
  final SignerModel signer;
  const _ReviewSignerTile({required this.signer});

  @override
  Widget build(BuildContext context) {
    final fieldCount = signer.fields.length;
    final isNeedsToSign = signer.role == SignerRole.needsToSign;

    return Container(
      decoration: AppStyle.card(),
      child: ListTile(
        contentPadding: const EdgeInsets.only(left: 16),
        leading: AppAvatar(name: signer.signerName),
        title: Text(
          signer.signerName,
          style: Theme.of(context).textTheme.titleSmall,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              signer.signerEmail,
              style: Theme.of(context).textTheme.bodySmall,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              isNeedsToSign
                  ? fieldCount > 0
                        ? '${AppFormatter.itemCount(fieldCount)} placed'
                        : 'No fields placed'
                  : 'Receives a copy',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: isNeedsToSign && fieldCount == 0
                    ? AppColors.warning
                    : AppColors.textHint,
              ),
            ),
          ],
        ),
        trailing: isNeedsToSign
            ? Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Icon(
                  fieldCount > 0
                      ? Icons.check_circle_outline
                      : Icons.warning_amber_outlined,
                  color: fieldCount > 0 ? AppColors.success : AppColors.warning,
                  size: 20,
                ),
              )
            : const Padding(
                padding: EdgeInsets.only(right: 16),
                child: Icon(
                  Icons.mail_outline,
                  color: AppColors.textHint,
                  size: 20,
                ),
              ),
      ),
    );
  }
}

class _BottomActions extends StatelessWidget {
  final SignatureRequestController controller;
  const _BottomActions({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Obx(
            () => AppButton.primary(
              label: 'Send',
              isLoading: controller.isSending.value,
              onPressed: controller.isSending.value
                  ? null
                  : controller.submitRequest,
            ),
          ),
          const SizedBox(height: 8),
          AppButton.outlined(label: 'Back', onPressed: Get.back),
        ],
      ),
    );
  }
}

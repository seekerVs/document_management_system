import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import '../../../../../Commons/Widgets/app_button.dart';
import '../../../../../Utils/Constant/colors.dart';
import '../../../../../Utils/Constant/enum.dart';
import '../Controller/in_app_signing_controller.dart';
import '../Model/signature_field_model.dart';

class InAppSigningView extends StatefulWidget {
  const InAppSigningView({super.key});

  @override
  State<InAppSigningView> createState() => _InAppSigningViewState();
}

class _InAppSigningViewState extends State<InAppSigningView> {
  final InAppSigningController _controller = Get.find<InAppSigningController>();

  final GlobalKey _pdfKey = GlobalKey();
  Size _canvasSize = Size.zero;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _measureCanvas());
  }

  void _measureCanvas() {
    final box = _pdfKey.currentContext?.findRenderObject() as RenderBox?;
    if (box != null) setState(() => _canvasSize = box.size);
  }

  @override
  Widget build(BuildContext context) {
    final request = _controller.request;
    final signer = _controller.signer;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          request.documentName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        leading: IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: Get.back,
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(32),
          child: Container(
            width: double.infinity,
            color: AppColors.primarySurface,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Text(
              'Signing as ${signer.signerName}',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: AppColors.primary,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return Stack(
                  children: [
                    // PDF viewer
                    SizedBox.expand(
                      key: _pdfKey,
                      child: SfPdfViewer.network(
                        request.documentUrl,
                        scrollDirection: PdfScrollDirection.vertical,
                        canShowScrollHead: false,
                      ),
                    ),
                    // Field overlays
                    Obx(() {
                      final size = _canvasSize == Size.zero
                          ? Size(constraints.maxWidth, constraints.maxHeight)
                          : _canvasSize;
                      return Stack(
                        children: _controller.fields
                            .map(
                              (f) => _SigningFieldOverlay(
                                key: ValueKey(f.fieldId),
                                field: f,
                                controller: _controller,
                                canvasSize: size,
                              ),
                            )
                            .toList(),
                      );
                    }),
                  ],
                );
              },
            ),
          ),
          _BottomBar(controller: _controller),
        ],
      ),
    );
  }
}

class _SigningFieldOverlay extends StatelessWidget {
  final SignatureFieldModel field;
  final InAppSigningController controller;
  final Size canvasSize;

  const _SigningFieldOverlay({
    super.key,
    required this.field,
    required this.controller,
    required this.canvasSize,
  });

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final isFilled = controller.isFieldFilled(field.fieldId);
      final color = controller.fieldColor(field.fieldId);
      final imageBytes = controller.signatureImages[field.fieldId];
      final textValue = controller.fieldValues[field.fieldId];

      return Positioned(
        left: field.x,
        top: field.y,
        child: GestureDetector(
          onTap: () => controller.onFieldTap(field),
          child: Container(
            width: field.width,
            height: field.height,
            decoration: BoxDecoration(
              color: color.withAlpha(isFilled ? 20 : 30),
              border: Border.all(color: color, width: 1.5),
              borderRadius: BorderRadius.circular(6),
            ),
            child: isFilled
                ? _FilledFieldContent(
                    field: field,
                    imageBytes: imageBytes,
                    textValue: textValue,
                    color: color,
                  )
                : _EmptyFieldContent(field: field, color: color),
          ),
        ),
      );
    });
  }
}

class _EmptyFieldContent extends StatelessWidget {
  final SignatureFieldModel field;
  final Color color;
  const _EmptyFieldContent({required this.field, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(_icon, color: color, size: 14),
        const SizedBox(width: 4),
        Text(
          _label,
          style: TextStyle(
            color: color,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  IconData get _icon {
    switch (field.type) {
      case SignatureFieldType.signature:
        return Icons.draw_outlined;
      case SignatureFieldType.initials:
        return Icons.text_fields_outlined;
      case SignatureFieldType.dateSigned:
        return Icons.calendar_today_outlined;
      case SignatureFieldType.textbox:
        return Icons.text_snippet_outlined;
    }
  }

  String get _label {
    switch (field.type) {
      case SignatureFieldType.signature:
        return 'Tap to sign';
      case SignatureFieldType.initials:
        return 'Tap for initials';
      case SignatureFieldType.dateSigned:
        return 'Tap for date';
      case SignatureFieldType.textbox:
        return 'Tap to type';
    }
  }
}

class _FilledFieldContent extends StatelessWidget {
  final SignatureFieldModel field;
  final Uint8List? imageBytes;
  final String? textValue;
  final Color color;

  const _FilledFieldContent({
    required this.field,
    required this.imageBytes,
    required this.textValue,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    if (imageBytes != null) {
      return Padding(
        padding: const EdgeInsets.all(4),
        child: Image.memory(imageBytes!, fit: BoxFit.contain),
      );
    }
    return Center(
      child: Text(
        textValue ?? '',
        style: TextStyle(
          fontSize: field.type == SignatureFieldType.dateSigned ? 10 : 12,
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w500,
        ),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        textAlign: TextAlign.center,
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  final InAppSigningController controller;
  const _BottomBar({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 8,
            offset: Offset(0, -2),
          ),
        ],
      ),
      child: Obx(() {
        final filled = controller.fields
            .where((f) => controller.isFieldFilled(f.fieldId))
            .length;
        final total = controller.fields.length;

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '$filled of $total fields completed',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                if (filled == total)
                  const Icon(
                    Icons.check_circle,
                    color: AppColors.success,
                    size: 16,
                  ),
              ],
            ),
            const SizedBox(height: 10),
            AppButton.primary(
              label: 'Confirm & Sign',
              onPressed: controller.allFieldsFilled
                  ? controller.confirmSigning
                  : null,
            ),
            const SizedBox(height: 8),
            AppButton.outlined(
              label: 'Decline to Sign',
              onPressed: controller.declineSigning,
            ),
          ],
        );
      }),
    );
  }
}

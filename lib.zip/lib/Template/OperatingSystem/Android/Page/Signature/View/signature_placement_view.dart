import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import '../../../../../Commons/Widgets/app_button.dart';
import '../../../../../Utils/Constant/colors.dart';
import '../Controller/signature_placement_controller.dart';
import '../Controller/signature_request_controller.dart';
import '../Widget/field_toolbar.dart';
import '../Widget/signature_field_overlay.dart';
import '../Widget/signer_switcher.dart';

class SignaturePlacementView extends StatefulWidget {
  const SignaturePlacementView({super.key});

  @override
  State<SignaturePlacementView> createState() => _SignaturePlacementViewState();
}

class _SignaturePlacementViewState extends State<SignaturePlacementView> {
  final SignaturePlacementController _controller =
      Get.find<SignaturePlacementController>();
  final SignatureRequestController _requestController =
      Get.find<SignatureRequestController>();

  final GlobalKey _pdfKey = GlobalKey();
  final PdfViewerController _pdfViewerController = PdfViewerController();
  Size _canvasSize = Size.zero;

  @override
  void initState() {
    super.initState();
    // Initial measure attempt after first frame
    WidgetsBinding.instance.addPostFrameCallback((_) => _measureCanvas());
  }

  // Measure after PDF has rendered — called from onDocumentLoaded
  void _measureCanvas() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final box = _pdfKey.currentContext?.findRenderObject() as RenderBox?;
      if (box != null && box.size != Size.zero) {
        setState(() => _canvasSize = box.size);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final doc = _requestController.selectedDocument.value;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          doc?.name ?? 'Place Fields',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        leading: IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: Get.back,
        ),
        actions: [
          TextButton(
            onPressed: _controller.goToReview,
            child: const Text('Next'),
          ),
        ],
      ),
      body: Column(
        children: [
          // Signer context switcher
          SignerSwitcher(controller: _controller),
          // PDF + field overlays
          Expanded(
            child: doc == null
                ? const Center(child: Text('No document selected.'))
                : LayoutBuilder(
                    builder: (context, constraints) {
                      return Stack(
                        children: [
                          // PDF viewer — measure canvas after document loads
                          SizedBox.expand(
                            key: _pdfKey,
                            child: SfPdfViewer.file(
                              File(doc.file.path),
                              controller: _pdfViewerController,
                              scrollDirection: PdfScrollDirection.vertical,
                              canShowScrollHead: false,
                              onDocumentLoaded: (_) => _measureCanvas(),
                            ),
                          ),
                          // Draggable field overlays
                          Obx(() {
                            // fieldPositions is Rx — reading it makes this reactive
                            // allFields reads from signers which updates fieldPositions
                            final _ = _controller.fieldPositions.entries
                                .toList();
                            final size = _canvasSize == Size.zero
                                ? Size(
                                    constraints.maxWidth,
                                    constraints.maxHeight,
                                  )
                                : _canvasSize;
                            return Stack(
                              children: _controller.allFields
                                  .map(
                                    (entry) => SignatureFieldOverlay(
                                      key: ValueKey(entry.field.fieldId),
                                      field: entry.field,
                                      signer: entry.signer,
                                      color: _signerColor(entry.signerIndex),
                                      controller: _controller,
                                      canvasWidth: size.width,
                                      canvasHeight: size.height,
                                    ),
                                  )
                                  .toList(),
                            );
                          }),
                        ],
                      );
                    },
                  ),
          ),
          // Field type toolbar
          FieldToolbar(
            onFieldTap: (type) {
              final size = _canvasSize == Size.zero
                  ? MediaQuery.of(context).size
                  : _canvasSize;
              _controller.addField(type, size.width, size.height);
            },
          ),
        ],
      ),
    );
  }

  // Color-coded per signer index
  Color _signerColor(int index) {
    const colors = [
      AppColors.primary,
      AppColors.signatureCompleted,
      AppColors.signaturePending,
      AppColors.error,
    ];
    return colors[index % colors.length];
  }
}

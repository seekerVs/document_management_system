import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../Commons/Widgets/app_avatar.dart';
import '../../../../../Utils/Constant/colors.dart';
import '../Controller/signature_placement_controller.dart';

class SignerSwitcher extends StatelessWidget {
  final SignaturePlacementController controller;

  const SignerSwitcher({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final signers = controller.activeSigners;
      if (signers.isEmpty) return const SizedBox.shrink();
      final activeIndex = controller.activeSignerIndex.value.clamp(
        0,
        signers.length - 1,
      );
      final activeSigner = signers[activeIndex];

      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        color: AppColors.backgroundWhite,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Now Signing: ${activeSigner.signerName}',
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(color: AppColors.textSecondary),
            ),
            if (signers.length > 1) ...[
              const SizedBox(height: 8),
              // Signer avatar row for switching
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(signers.length, (i) {
                    final isActive = i == activeIndex;
                    return GestureDetector(
                      onTap: () => controller.switchSigner(i),
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: isActive
                              ? AppColors.primarySurface
                              : AppColors.backgroundGrey,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isActive
                                ? AppColors.primary
                                : Colors.transparent,
                          ),
                        ),
                        child: Row(
                          children: [
                            AppAvatar(name: signers[i].signerName, radius: 10),
                            const SizedBox(width: 6),
                            Text(
                              signers[i].signerName.split(' ').first,
                              style: Theme.of(context).textTheme.bodySmall
                                  ?.copyWith(
                                    color: isActive
                                        ? AppColors.primary
                                        : AppColors.textSecondary,
                                    fontWeight: isActive
                                        ? FontWeight.w600
                                        : FontWeight.normal,
                                  ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                ),
              ),
            ],
          ],
        ),
      );
    });
  }
}

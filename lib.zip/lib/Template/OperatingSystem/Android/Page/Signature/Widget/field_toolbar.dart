import 'package:flutter/material.dart';
import '../../../../../Utils/Constant/colors.dart';
import '../../../../../Utils/Constant/enum.dart';

class FieldToolbar extends StatelessWidget {
  final void Function(SignatureFieldType) onFieldTap;

  const FieldToolbar({super.key, required this.onFieldTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 8,
            offset: Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _ToolbarItem(
            icon: Icons.draw_outlined,
            label: 'Signature',
            onTap: () => onFieldTap(SignatureFieldType.signature),
          ),
          _ToolbarItem(
            icon: Icons.text_fields_outlined,
            label: 'Initials',
            onTap: () => onFieldTap(SignatureFieldType.initials),
          ),
          _ToolbarItem(
            icon: Icons.calendar_today_outlined,
            label: 'Date Signed',
            onTap: () => onFieldTap(SignatureFieldType.dateSigned),
          ),
          _ToolbarItem(
            icon: Icons.text_snippet_outlined,
            label: 'Textbox',
            onTap: () => onFieldTap(SignatureFieldType.textbox),
          ),
        ],
      ),
    );
  }
}

class _ToolbarItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ToolbarItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppColors.primarySurface,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: AppColors.primary, size: 22),
          ),
          const SizedBox(height: 4),
          Text(label, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../../../../../Utils/Constant/colors.dart';
import '../../../../../Utils/Constant/enum.dart';
import '../Model/signature_field_model.dart';
import '../Model/signature_request_model.dart';
import '../Controller/signature_placement_controller.dart';

class SignatureFieldOverlay extends StatefulWidget {
  final SignatureFieldModel field;
  final SignerModel signer;
  final Color color;
  final SignaturePlacementController controller;
  final double canvasWidth;
  final double canvasHeight;

  const SignatureFieldOverlay({
    super.key,
    required this.field,
    required this.signer,
    required this.color,
    required this.controller,
    required this.canvasWidth,
    required this.canvasHeight,
  });

  @override
  State<SignatureFieldOverlay> createState() => _SignatureFieldOverlayState();
}

class _SignatureFieldOverlayState extends State<SignatureFieldOverlay> {
  bool _showDelete = false;

  // Toggle delete button visibility
  void _onTap() => setState(() => _showDelete = !_showDelete);

  @override
  Widget build(BuildContext context) {
    final pos = widget.controller.fieldPositions[widget.field.fieldId];
    if (pos == null) return const SizedBox.shrink();

    return Positioned(
      left: pos.x,
      top: pos.y,
      child: GestureDetector(
        onTap: _onTap,
        onPanUpdate: (d) {
          widget.controller.updateFieldPosition(
            widget.field.fieldId,
            d.delta.dx,
            d.delta.dy,
            widget.canvasWidth,
            widget.canvasHeight,
          );
        },
        onPanEnd: (_) => widget.controller.commitFieldPosition(
          widget.field.fieldId,
          widget.signer,
        ),
        child: SizedBox(
          width: widget.field.width,
          height: widget.field.height,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              // Field body
              Container(
                width: widget.field.width,
                height: widget.field.height,
                decoration: BoxDecoration(
                  color: widget.color.withAlpha(25),
                  border: Border.all(color: widget.color, width: 1.5),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _fieldIcon(widget.field.type),
                      color: widget.color,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _fieldLabel(widget.field.type),
                      style: TextStyle(
                        color: widget.color,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              // Delete button
              if (_showDelete)
                Positioned(
                  top: -10,
                  right: -10,
                  child: GestureDetector(
                    onTap: () => widget.controller.deleteField(
                      widget.field.fieldId,
                      widget.signer,
                    ),
                    child: Container(
                      width: 22,
                      height: 22,
                      decoration: const BoxDecoration(
                        color: AppColors.error,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.close,
                        color: Colors.white,
                        size: 14,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _fieldIcon(SignatureFieldType type) {
    switch (type) {
      case SignatureFieldType.signature:
        return Icons.draw_outlined;
      case SignatureFieldType.initials:
        return Icons.text_fields_outlined;
      case SignatureFieldType.dateSigned:
        return Icons.calendar_today_outlined;
      case SignatureFieldType.textbox:
        return Icons.text_snippet_outlined;
    }
  }

  String _fieldLabel(SignatureFieldType type) {
    switch (type) {
      case SignatureFieldType.signature:
        return 'Signature';
      case SignatureFieldType.initials:
        return 'Initials';
      case SignatureFieldType.dateSigned:
        return 'Date Signed';
      case SignatureFieldType.textbox:
        return 'Textbox';
    }
  }
}
